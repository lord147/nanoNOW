<?php 

$nano_address = "xxx";

?>