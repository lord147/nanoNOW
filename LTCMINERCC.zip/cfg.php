<?php

$useragent = "Mozilla/5.0 (Linux; Android 8.1.0; Redmi 6A Build/O11019; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/71.0.3578.99 Mobile Safari/537.36";

$cookie = "PHPSESSID=b02c6cf35a85cf6b931fffa0163e25a2";